#define  _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <stdlib.h>
#include <random>
#include <vector>

#define Width 1000
#define Height 700

struct Point {
public:
	float x, y, z;
};
struct RGB {
public:
	float r, g, b;
};

class Shape {
public:
	int way;
	float add_x, add_y;
	bool cut;
	Point startpoint, endpoint;

	void addvertex(Point point) {
		vertice.push_back(point);
	}
	void addcolor(RGB rgb) {
		color.push_back(rgb);
	}

	void add_xy() {
		for (int i = 0; i < vertice.size(); ++i) {
			vertice[i].x += add_x;
			vertice[i].y += add_y;
		}
	}

	const std::vector<Point>& getvertices() const {
		return vertice;
	}
	const std::vector<RGB>& getcolor() const {
		return color;
	}

private:
	std::vector<Point> vertice;
	std::vector<RGB> color;
};


void make_vertexShaders();
void make_fragmentShaders();
void make_shaderProgram();
GLvoid drawScene();
GLvoid Reshape(int w, int h);
char* filetobuf(const char* file);
void initbuffer();
void Mouse(int, int, int, int);
void MouseMotion(int x, int y);
GLvoid Keyboard(unsigned char key, int x, int y);
void move_box(int value);
void add_shape(int);
void move_shape(int);
void check_slice();

int ccw(Point a, Point b, Point p);
bool check_line_on(Point a, Point q, Point b);
bool checking_cross(Point p1, Point q1, Point p2, Point q2);



GLchar* vertexSource, * fragmentSource; //--- �ҽ��ڵ� ���� ����
GLuint vertexShader, fragmentShader; //--- ���̴� ��ü
GLuint shaderProgramID;
GLuint vao, boxvbo[2];
GLfloat box[4][3] = {
	{-0.2f,-0.8f,0.f},
	{-0.2f,-0.9f,0.f},
	{0.2f,-0.9f,0.f},
	{0.2f,-0.8f,0.f}
};
GLfloat box_RGB[4][3];
float box_move_way;

GLuint linevbo[2];
float cutting_line[2][3];
float cutting_line_rgb[2][3];
bool mouse_down;

GLuint polygonvbo[2];
GLuint coursevbo;

float adding_x, adding_y;
int add_speed;

std::vector<Shape> polygons;

bool fill_line;
bool see_course;

void main(int argc, char** argv) //--- ������ ����ϰ� �ݹ��Լ� ����
{
	//--- ������ �����ϱ�
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(Width, Height);
	glutCreateWindow("Computer Grapics - Let's Slice");
	glewExperimental = GL_TRUE;
	glewInit();
	make_shaderProgram();
	for (int i = 0; i < 4; ++i) {
		box_RGB[i][0] = 0.0f;
		box_RGB[i][1] = 0.0f;
		box_RGB[i][2] = 1.0f;
	}
	{
		box_move_way = 0.01f;
	}


	{
		adding_x = 0.01f;
		adding_y = 0.00125f;
		add_speed = 1000;
	}



	{
		std::cout << "l/L: ��� ���̱�/ �����" << std::endl;
		std::cout << "m/M: �׸��� ��� ���� LINE/FILL" << std::endl;
		std::cout << "-/+: ���� �ӵ� ����/����" << std::endl;
		std::cout << "q/Q: ���α׷� ����" << std::endl;


	}
	initbuffer();
	//--- ���̴� �о�ͼ� ���̴� ���α׷� �����
	glutDisplayFunc(drawScene); //--- ��� �ݹ� �Լ�
	glutReshapeFunc(Reshape);
	glutKeyboardFunc(Keyboard);
	glutMotionFunc(MouseMotion);
	glutMouseFunc(Mouse);
	glutTimerFunc(10, move_box, 0);
	glutTimerFunc(add_speed, add_shape, 0);
	glutMainLoop();
}

GLvoid drawScene() //--- �ݹ� �Լ�: �׸��� �ݹ� �Լ�
{
	GLfloat rColor, gColor, bColor;
	rColor = gColor = 0.5;
	bColor = 1.0;
	glClearColor(rColor, gColor, bColor, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);
	glUseProgram(shaderProgramID);
	glBindVertexArray(vao);

	int PosLocation = glGetAttribLocation(shaderProgramID, "in_Position"); //	: 0  Shader�� 'layout (location = 0)' �κ�
	int ColorLocation = glGetAttribLocation(shaderProgramID, "in_Color"); //	: 1
	glEnableVertexAttribArray(PosLocation);
	glEnableVertexAttribArray(ColorLocation);
	glBindBuffer(GL_ARRAY_BUFFER, boxvbo[0]);
	glVertexAttribPointer(PosLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
	glBindBuffer(GL_ARRAY_BUFFER, boxvbo[1]);
	glVertexAttribPointer(ColorLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);


	for (auto& poly : polygons) {
		std::vector<float> vertex_pos;
		std::vector<float> rgb_color;
		const std::vector<Point>& vertice = poly.getvertices();
		const std::vector<RGB>& color = poly.getcolor();
		for (auto& vertex : vertice) {
			vertex_pos.push_back(vertex.x);
			vertex_pos.push_back(vertex.y);
			vertex_pos.push_back(vertex.z);
		}
		for (auto& rgb : color) {
			rgb_color.push_back(rgb.r);
			rgb_color.push_back(rgb.g);
			rgb_color.push_back(rgb.b);
		}
		if (see_course) {
			std::vector<float> course_pos;
			course_pos.push_back(poly.startpoint.x);
			course_pos.push_back(poly.startpoint.y);
			course_pos.push_back(poly.startpoint.z);
			course_pos.push_back(poly.endpoint.x);
			course_pos.push_back(poly.endpoint.y);
			course_pos.push_back(poly.endpoint.z);
			glBindBuffer(GL_ARRAY_BUFFER, coursevbo);
			glBufferData(GL_ARRAY_BUFFER, sizeof(float) * course_pos.size(), course_pos.data(), GL_STATIC_DRAW);
			glVertexAttribPointer(PosLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
			glDrawArrays(GL_LINES, 0, 2);
		}
		glBindBuffer(GL_ARRAY_BUFFER, polygonvbo[0]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertex_pos.size(), vertex_pos.data(), GL_STATIC_DRAW);
		glVertexAttribPointer(PosLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
		glBindBuffer(GL_ARRAY_BUFFER, polygonvbo[1]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(float) * rgb_color.size(), rgb_color.data(), GL_STATIC_DRAW);
		glVertexAttribPointer(ColorLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
		if (fill_line)
		{
			glLineWidth(2);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		else	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glDrawArrays(GL_TRIANGLE_FAN, 0, vertex_pos.size() / 3);

	}
	if (mouse_down) {
		glBindBuffer(GL_ARRAY_BUFFER, linevbo[0]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(cutting_line), cutting_line, GL_STATIC_DRAW);
		glVertexAttribPointer(PosLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
		glBindBuffer(GL_ARRAY_BUFFER, linevbo[1]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(cutting_line_rgb), cutting_line_rgb, GL_STATIC_DRAW);
		glVertexAttribPointer(ColorLocation, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);
		glLineWidth(2);
		glDrawArrays(GL_LINES, 0, 2);
	}



	glDisableVertexAttribArray(PosLocation); // Disable �ʼ�!
	glDisableVertexAttribArray(ColorLocation);

	glutSwapBuffers(); // ȭ�鿡 ����ϱ�
}
GLvoid Reshape(int w, int h) //--- �ݹ� �Լ�: �ٽ� �׸��� �ݹ� �Լ�
{
	glViewport(0, 0, w, h);
}
void make_vertexShaders()
{
	vertexSource = filetobuf("vertex_project.glsl");
	//--- ���ؽ� ���̴� ��ü �����
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	//--- ���̴� �ڵ带 ���̴� ��ü�� �ֱ�
	glShaderSource(vertexShader, 1, (const GLchar**)&vertexSource, 0);
	//--- ���ؽ� ���̴� �������ϱ�
	glCompileShader(vertexShader);
	//--- �������� ����� ���� ���� ���: ���� üũ
	GLint result;
	GLchar errorLog[512];
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, errorLog);
		std::cout << "ERROR: vertex shader ������ ����\n" << errorLog << std::endl;
		return;
	}
}
void make_fragmentShaders()
{
	fragmentSource = filetobuf("fragment_project.glsl");
	//--- �����׸�Ʈ ���̴� ��ü �����
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	//--- ���̴� �ڵ带 ���̴� ��ü�� �ֱ�
	glShaderSource(fragmentShader, 1, (const GLchar**)&fragmentSource, 0);
	//--- �����׸�Ʈ ���̴� ������
	glCompileShader(fragmentShader);
	//--- �������� ����� ���� ���� ���: ������ ���� üũ
	GLint result;
	GLchar errorLog[512];
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, errorLog);
		std::cerr << "ERROR: fragment shader ������ ����\n" << errorLog << std::endl;
		return;
	}
}
void make_shaderProgram()
{
	make_vertexShaders(); //--- ���ؽ� ���̴� �����
	make_fragmentShaders(); //--- �����׸�Ʈ ���̴� �����
	//-- shader Program
	shaderProgramID = glCreateProgram();
	glAttachShader(shaderProgramID, vertexShader);
	glAttachShader(shaderProgramID, fragmentShader);
	glLinkProgram(shaderProgramID);
	//--- ���̴� �����ϱ�
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
	//--- Shader Program ����ϱ�
	glUseProgram(shaderProgramID);
}
char* filetobuf(const char* file)
{
	FILE* fptr;
	long length;
	char* buf;
	fptr = fopen(file, "rb"); // Open file for reading
	if (!fptr) // Return NULL on failure
		return NULL;
	fseek(fptr, 0, SEEK_END); // Seek to the end of the file
	length = ftell(fptr); // Find out how many bytes into the file we are
	buf = (char*)malloc(length + 1); // Allocate a buffer for the entire length of the file and a null terminator
	fseek(fptr, 0, SEEK_SET); // Go back to the beginning of the file
	fread(buf, length, 1, fptr); // Read the contents of the file in to the buffer
	fclose(fptr); // Close the file
	buf[length] = 0; // Null terminator
	return buf; // Return the buffer
}
void initbuffer() {
	glGenVertexArrays(1, &vao);
	glGenBuffers(2, boxvbo);
	glGenBuffers(2, polygonvbo);
	glGenBuffers(2, linevbo);
	glGenBuffers(1, &coursevbo);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, boxvbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(box), box, GL_DYNAMIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, boxvbo[1]);
	glBufferData(GL_ARRAY_BUFFER,sizeof(box_RGB), box_RGB, GL_STATIC_DRAW);

}
void Mouse(int button, int state, int x, int y)
{
	GLfloat halfx = Width / 2;
	GLfloat halfy = Height / 2;
	GLclampf mousex = (x - halfx) / halfx;
	GLclampf mousey = 1 - (y / halfy);
	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON || button == GLUT_RIGHT_BUTTON) {
			mouse_down = true;
			cutting_line[0][0] = mousex;
			cutting_line[0][1] = mousey;
			cutting_line[0][2] = 0.f;
			cutting_line[1][0] = mousex;
			cutting_line[1][1] = mousey;
			cutting_line[1][2] = 0.f;
		}
	}
	else if (state == GLUT_UP) {
		if (button == GLUT_LEFT_BUTTON || button == GLUT_RIGHT_BUTTON) {
			mouse_down = false;

			// ���⼭ ���� �߸����� üũ
			check_slice();
			//
			cutting_line[0][0] = mousex;
			cutting_line[0][1] = mousey;
			cutting_line[0][2] = 0.f;
			cutting_line[1][0] = mousex;
			cutting_line[1][1] = mousey;
			cutting_line[1][2] = 0.f;
		}
	}
	glutPostRedisplay();
}
void MouseMotion(int x, int y) {
	GLfloat halfx = Width / 2;
	GLfloat halfy = Height / 2;
	GLclampf mousex = (x - halfx) / halfx;
	GLclampf mousey = 1 - (y / halfy);
	if (mouse_down) {
		cutting_line[1][0] = mousex;
		cutting_line[1][1] = mousey;
		cutting_line[1][2] = 0.f;
	}
	glutPostRedisplay();
}
GLvoid Keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'l':
	case 'L':
		if (see_course)
			see_course = false;
		else
			see_course = true;
		break;
	case 'm':
	case 'M':
		if (fill_line)
			fill_line = false;
		else
			fill_line = true;
		break;
	case '-':
		if (adding_x > 0.005f) {
			adding_x -= 0.005f;
		}
		if (adding_y > 0.0005f)
		{
			adding_y -= 0.0005f;
		}		
		break;
	case '+':
		adding_x += 0.005f;
		adding_y += 0.0005f;
		for (auto& polygon : polygons) {
			if (polygon.add_y != 0) {
				if (polygon.add_x > 0)
					polygon.add_x += 0.005f;
				else {
					polygon.add_x -= 0.005f;
				}
			}
		}
		break;
	case 'q':
	case 'Q':
		exit(0);
		break;
	}
	glutPostRedisplay();
}
void move_box(int value) {
	for (int i = 0; i < 4; ++i) {
		box[i][0] += box_move_way;
	}
	if ((box[0][0] <= -1.f)||(box[3][0] >= 1.f)) {
		box_move_way *= -1;
	}
	glBindBuffer(GL_ARRAY_BUFFER, boxvbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(box), box, GL_DYNAMIC_DRAW);
	glutTimerFunc(10, move_box, value);
	glutPostRedisplay();

}

std::random_device rd;
std::mt19937 gen(rd());
std::uniform_real_distribution<float> color(0, 1);
std::uniform_real_distribution<float> y_pos(-0.3, 0.8);
std::uniform_int_distribution<int> vertex_count(3, 4);
std::uniform_int_distribution<int> way_cos(0, 1);
void add_shape(int value) {
	Shape poly;

	Point point;
	RGB rgb;
	int count= vertex_count(gen);
	poly.way = way_cos(gen);
	poly.cut = false;
	if (count == 3) {
		if (poly.way == 0) {		// left -> right
			point = { -1.1f,y_pos(gen),0.f };
			poly.addvertex(point);
			point = { point.x + 0.2f,point.y,0.f };
			poly.addvertex(point);
			point = { point.x - 0.2f,point.y + 0.2f,0.f };
			poly.addvertex(point);
			if (point.y - 0.2f < 0.1f) {
				poly.add_x = adding_x;
				poly.add_y = adding_y;
			}
			else {
				poly.add_x = adding_x;
				poly.add_y = -adding_y;
			}
		}
		else {						// right -> left
			point = { 1.1f,y_pos(gen),0.f };
			poly.addvertex(point);
			point = { point.x + 0.2f,point.y,0.f };
			poly.addvertex(point);
			point = { point.x - 0.2f,point.y + 0.2f,0.f };
			poly.addvertex(point);
			if (point.y - 0.2f < 0.1f) {
				poly.add_x = -adding_x;
				poly.add_y = adding_y;
			}
			else {
				poly.add_x = -adding_x;
				poly.add_y = -adding_y;
			}
		}
		for (int i = 0; i < 3; ++i)
		{
			rgb.r = color(gen);
			rgb.g = color(gen);
			rgb.b = color(gen);
			poly.addcolor(rgb);
		}
	}
	else if (count == 4) {
		if (poly.way == 0) {		// left -> right
			point = { -1.1f,y_pos(gen),0.f };
			poly.addvertex(point);
			point = { point.x + 0.2f,point.y,0.f };
			poly.addvertex(point);
			point = { point.x,point.y + 0.2f,0.f };
			poly.addvertex(point);
			point = { point.x - 0.2f,point.y,0.f };
			poly.addvertex(point);
			if (point.y - 0.2f < 0.1f) {
				poly.add_x = adding_x;
				poly.add_y = adding_y;
			}
			else {
				poly.add_x = adding_x;
				poly.add_y = -adding_y;
			}
		}
		else {						// right -> left
			point = { 1.1f,y_pos(gen),0.f };
			poly.addvertex(point);
			point = { point.x + 0.2f,point.y,0.f };
			poly.addvertex(point);
			point = { point.x,point.y + 0.2f,0.f };
			poly.addvertex(point);
			point = { point.x - 0.2f,point.y,0.f };
			poly.addvertex(point);
			if (point.y - 0.2f < 0.1f) {
				poly.add_x = -adding_x;
				poly.add_y = adding_y;
			}
			else {
				poly.add_x = -adding_x;
				poly.add_y = -adding_y;
			}
		}
		for (int i = 0; i < 4; ++i)
		{
			rgb.r = color(gen);
			rgb.g = color(gen);
			rgb.b = color(gen);
			poly.addcolor(rgb);
		}
	}
	poly.startpoint.x = point.x;
	poly.startpoint.y = point.y - 0.1f;
	poly.endpoint.x = point.x + poly.add_x * 1000;
	poly.endpoint.y = point.y + poly.add_y * 1000;

	polygons.push_back(poly);
	glutTimerFunc(10, move_shape, polygons.size() - 1);
	glutTimerFunc(add_speed, add_shape, value);
	glutPostRedisplay();
}
void move_shape(int value) {
	if (value >= polygons.size())
		return;
	Shape& poly = polygons[value];
	float speed_y, speed_x;
	speed_x = poly.add_x;
	speed_y = poly.add_y;
	poly.add_xy();
	const std::vector<Point>& vertice = poly.getvertices();
	if (poly.add_y != 0.f) {
		for (auto& vertex : vertice) {
			if (vertex.x >= box[0][0] && vertex.x <= box[2][0]) {
				if (vertex.y >= box[0][1] - 0.01f && vertex.y <= box[0][1]) {
					poly.add_y = 0.f;
					poly.add_x = box_move_way;
					break;
				}
			}
		}
		for (auto& vertex : vertice) {
			if (vertex.y < box[0][1] - 0.01f) {
				poly.add_y = speed_y;
				poly.add_x = speed_x;
				break;
			}
		}
	}
	else {
		if ((poly.add_x < box_move_way)||(poly.add_x>box_move_way)) {
			poly.add_x *= -1;
		}
	}
	if (poly.add_y != 0) {
		if (vertice[2].y && vertice[1].y && vertice[0].y < -1.0f) {
			polygons.erase(polygons.begin() + value);
		}
		if (poly.way == 0) {
			if (vertice[0].x > 1.0f) {
				polygons.erase(polygons.begin() + value);
				//std::cout << polygons.size() << std::endl;
			}
		}
		else if (poly.way == 1) {
			if (vertice[1].x < -1.0f) {
				polygons.erase(polygons.begin() + value);
				//std::cout << polygons.size() << std::endl;
			}
		}
		if (poly.cut) {
			polygons.erase(polygons.begin() + value);
		}
	}
	if (value >= polygons.size())
		return;
	glutTimerFunc(10, move_shape, value);
	glutPostRedisplay();
}


std::uniform_real_distribution<float> slice_x_speed(0.001, 0.003);
std::uniform_real_distribution<float> slice_y_speed(0.004, 0.008);
void check_slice() {
	Point mousepoint[2];
	Point point;
	RGB rgb;
	mousepoint[0] = { cutting_line[0][0],cutting_line[0][1],0.f };
	mousepoint[1] = { cutting_line[1][0],cutting_line[1][1],0.f };
	for (auto& polygon : polygons) {
		if (polygon.add_y != 0.f) {
			int crosscount = 0;
			const std::vector<Point>& vertice = polygon.getvertices();
			// ���� ���� üũ
			for (int i = 0; i < vertice.size() - 1; ++i) {
				if (checking_cross(mousepoint[0], mousepoint[1], vertice[i], vertice[i + 1])) {
					++crosscount;
				}
			}

			if (checking_cross(mousepoint[0], mousepoint[1], vertice[vertice.size() - 1], vertice[0])) {
				++crosscount;
			}
			// ������ 2���� ��������
			if (crosscount == 2) {
				polygon.cut = true;
			}
		}
	}



	for (auto& polygon : polygons) {
		if (polygon.cut)
		{
			const std::vector<Point>& vertice = polygon.getvertices();
			const std::vector<RGB>& color = polygon.getcolor();
			Shape poly;
			Shape poly2;
			Point point;
			if (vertice.size() == 4) {
				point = vertice[3];
				point.x -= 0.05f;
				point.y += 0.05f;
				poly.addvertex(point);
				point = vertice[0];
				point.x -= 0.05f;
				point.y += 0.05f;
				poly.addvertex(point);
				point = vertice[2];
				point.x -= 0.05f;
				point.y += 0.05f;
				poly.addvertex(point);
				poly.add_x = -slice_x_speed(gen);
				poly.add_y = -slice_y_speed(gen);
				poly.way = polygon.way;
				poly.cut = false;
				rgb = color[3];
				poly.addcolor(rgb);
				rgb = color[0];
				poly.addcolor(rgb);
				rgb = color[2];
				poly.addcolor(rgb);

				point = vertice[1];
				point.x += 0.05f;
				poly2.addvertex(point);
				point = vertice[2];
				point.x += 0.05f;
				poly2.addvertex(point);
				point = vertice[0];
				point.x += 0.05f;
				poly2.addvertex(point);
				poly2.add_x = slice_x_speed(gen);
				poly2.add_y = -slice_y_speed(gen);
				poly2.way = polygon.way;
				poly2.cut = false;
				rgb = color[1];
				poly2.addcolor(rgb);
				rgb = color[2];
				poly2.addcolor(rgb);
				rgb = color[0];
				poly2.addcolor(rgb);
			}
			else if (vertice.size() == 3) {

				point = vertice[2];
				point.x += vertice[1].x;
				point.y += vertice[1].y;
				point.z += vertice[1].z;
				point.x /= 2;
				point.y /= 2;
				point.z /= 2;
				point.x -= 0.05f;
				point.y += 0.05f;
				poly.addvertex(point);
				point = vertice[2];
				point.x -= 0.05f;
				point.y += 0.05f;
				poly.addvertex(point);
				point = vertice[0];
				point.x -= 0.05f;
				point.y += 0.05f;
				poly.addvertex(point);
				poly.add_x = -slice_x_speed(gen);
				poly.add_y = -slice_y_speed(gen);
				poly.way = polygon.way;
				poly.cut = false;
				rgb.r = (color[2].r + color[1].r) / 2;
				rgb.g = (color[2].g + color[1].g) / 2;
				rgb.b = (color[2].b + color[1].b) / 2;
				poly.addcolor(rgb);
				rgb = color[2];
				poly.addcolor(rgb);
				rgb = color[0];
				poly.addcolor(rgb);

				point = vertice[2];
				point.x += vertice[1].x;
				point.y += vertice[1].y;
				point.z += vertice[1].z;
				point.x /= 2;
				point.y /= 2;
				point.z /= 2;
				point.x += 0.05f;
				poly2.addvertex(point);
				point = vertice[0];
				point.x += 0.05f;
				poly2.addvertex(point);
				point = vertice[1];
				point.x += 0.05f;
				poly2.addvertex(point);
				poly2.add_x = slice_x_speed(gen);
				poly2.add_y = -slice_y_speed(gen);
				poly2.way = polygon.way;
				poly2.cut = false;
				rgb.r = (color[2].r + color[1].r) / 2;
				rgb.g = (color[2].g + color[1].g) / 2;
				rgb.b = (color[2].b + color[1].b) / 2;
				poly2.addcolor(rgb);
				rgb = color[0];
				poly2.addcolor(rgb);
				rgb = color[1];
				poly2.addcolor(rgb);
			}
			polygons.push_back(poly);
			polygons.push_back(poly2);
			glutTimerFunc(10, move_shape, polygons.size() - 2);
			glutTimerFunc(10, move_shape, polygons.size() - 1);
		}
	}

}

int ccw(Point a, Point b, Point p) {
	double value = (b.y - a.y) * (p.x - b.x) - (b.x - a.x) * (p.y - b.y);
	if (value == 0)return 0;
	else if (value > 0) return 1;
	else if (value < 0) return -1;
}

bool check_line_on(Point a, Point q, Point b) {
	return (q.x <= std::max(a.x, b.x) && q.x >= std::min(a.x, b.x) &&
		    q.y <= std::max(a.y, b.y) && q.y >= std::min(a.y, b.y));
}


bool checking_cross(Point p1, Point q1, Point p2, Point q2) {

	int o1 = ccw(p1, q1, p2);
	int o2 = ccw(p1, q1, q2);
	int o3 = ccw(p2, q2, p1);
	int o4 = ccw(p2, q2, q1);

	if (o1 != o2 && o3 != o4)
	{
		return true;
	}
	if (o1 == 0 && check_line_on(p1, p2, q1)) return true;
	if (o2 == 0 && check_line_on(p1, q2, q1)) return true;
	if (o3 == 0 && check_line_on(p2, p1, q2)) return true;
	if (o4 == 0 && check_line_on(p2, q1, q2)) return true;

	return false;
}